"use strict";
/**
 * Made By Untitled
 * 작동을 안하는 기능이 있을 수도 있음.
 * 
 * Untitled 프로필은 Senko-san (Merijn Hendriks) 의 Easy Mode를 참고하여 추가하였습니다.
 */

 /**
 * Made By Untitled
 * 
 * Ver 1.2.6
 * Aki R6 대응 업데이트
 * 
 * ImproveSet, AllTraders4Stars 추가
 * 코드 최적화
 */

class Config
{
    constructor()
    {
        this.ChangeLog                 = true;        // 값 변경 로그를 활성화/비활성화 합니다.
        this.TestMode                  = false;       // 테스트중인 변경사항 
        this.ImproveSet                = true;        // 사양에 관한 설정을 변경합니다. [ 테스트 상으로는 로딩이 조금더 빠른거 같습니다.]
        this.GlobalLootChanceModifier  = 50;          // 글로벌 루트 찬스 (0.25 기본값)
        this.AllExaminedItems          = true;        // 모든 아이템의 Examined 상태로 만듭니다.
        this.MoneyStackMultiplier      = 1;           // 돈 스택 승수 (1 = 50만 루블, 10 = 500만 루블) 달러, 유로 포함
                                                      // Untitled 프로필을 사용시 MoneyStackMultiplier를 200으로 해주세요.
        this.AmmoStackMultiplier       = 1;           // 총알 스택 승수
        this.CleanT7                   = false        // T-7 노이즈 제거 및 시야 가림 제거
        this.priceMultiplier           = 1.8;         // 플리마켓 가격 승수
        this.RagFairMinLevel           = 10;          // 플리마켓 언락 레벨
        this.ItemsMarkedInraid         = false;       // 플리마켓 구매 아이템 인레이드 마크
        this.InventorySave             = false;       // 죽어도 아이템이 사라지지 않습니다.
        this.FastMagAmmoLoad           = false;       // 탄창 삽탄 속도 증가
        this.NoneFallingDamage         = false;       // 낙하 데미지 제거
        this.InfStamina                = false;       // 무한 스태미나
        this.FastStamina               = false;       // 스태미나 회복 속도 증가
        this.IncreasedBossChance       = true;        // 보스 스폰 확률 100
        this.Scav = {
            "ScavPlayCooldown"         : 1,           // 스캐브 플레이 쿨타임 ( 기본값 = 1200)
            "HardMode"                 : true         // 스캐브 난이도 조정 (테스트 단계 불안정) 
        }
        this.trader = {
            "updateTime"               : 3600,
            "fenceGridHeight"          : 240,
            "insurancePriceMultiplier" : 1,
            "insuranceReturnChance"    : 75,
            "RepairPriceMultiplier"    : 1,
            "AllTraders4Stars"         : true          // 트레이더 최대 우호도
        }
    }
}


module.exports.Config = Config;