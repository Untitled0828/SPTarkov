const { Config } = require("./config.js");
const { Callbacks } = require("./src/callbacks.js");
const { UntitledConfiguratorClass } = require("./src/mod.js");

module.exports.config = new Config();
module.exports.callbacks = new Callbacks();
module.exports.mod = new UntitledConfiguratorClass();